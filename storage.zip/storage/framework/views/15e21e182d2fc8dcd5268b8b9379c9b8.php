<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/connexion.css')); ?>">
    <title>JAE Connexion</title>
    <style>



    </style>
</head>

<body>
    
    <div class="bg">
            <div class="inscription ">
            <div class="container">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                <p>Bienvenue à la JAE</p>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error_message"><?php echo e(__($message)); ?></span><br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="email" id="email" name="email" autofocus autocomplete="username"  value="<?php echo e(old('email')); ?>" required placeholder="Email"><br>

                <input id="password" type="password" name="password"  autocomplete="current-password" required placeholder="Mot de passe" ><br>
                <div class="remember">
                    <input id="remember_me" type="checkbox" class="" name="remember">
                    <label for="remember_me" class=""><?php echo e(__('Se souvenir de moi')); ?></label> <br>
                </div>


                <input type="submit" value="Connexion"><br>
                <span class="hvntaccount"> Vous n'avez pas de compte? <a href="<?php echo e(route('rejoindre')); ?>">S'inscrire</a></span><br>
                <?php if(Route::has('password.request')): ?>
                    <a href="<?php echo e(route('password.request')); ?>" class="my-3"><?php echo e(__('Mot de passe oublié ?')); ?></a>
                <?php endif; ?>
                </form>

                <div class="drop drop-1"></div>
                <div class="drop drop-2">
                </div>
                <div class="drop drop-3"></div>
                <div class="drop drop-4">
                    
                </div>
                <div class="drop drop-5"></div>
            </div>

        </div>

    </div>

</body>
</html>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/JAE/resources/views/auth/login.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/styledashboarduser.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/material-kit.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('sass/pbootstrap.css')); ?>">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-KLZZ6W7HPR"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-KLZZ6W7HPR');
</script>

<body class="antialiased">

    <div class=" flex justify-between">

        <nav class="bg-color w-15 " style="height: calc(100vh+100%)">
            <div class=" py-4 sm:px-6 lg:py-8">
                <div class="flex flex-col justify-between " style="align-content:space-between; height:100vh">
                    <div class="flex flex-col items-center justify-between">
                        <div class="flex-shrink-0">
                            <a href="/"><img class="w-100" src="<?php echo e(asset('img/logo_header.png')); ?>"
                                    alt=""></a>
                        </div>
                        <div class=" md:block py-6">
                            <div class=" flex flex-col items-baseline justify-between space-y-6">
                                <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
                                <a href="<?php echo e(route('dashboard')); ?>" data-page="dashboard"
                                    class="text-white text-center w-100 items_menu rounded-md px-3 py-2 text-sm font-medium"
                                    aria-current="page"><i class="bi bi-border-style sm:block md:inline "></i>
                                    Programme</a>
                                <a href="<?php echo e(route('moncompte')); ?>" data-page="mon-compte"
                                    class="text-gray-300 text-center w-100 items_menu hover:text-white rounded-md px-3 py-2 text-sm font-medium"><i
                                        class="bi bi-person-fill-gear block md:inline"></i> Mon Compte</a>
                                <a href="<?php echo e(route('nos-programmes.historique')); ?>" data-page="mon-historique"
                                    class="text-gray-300 text-center w-100 items_menu  hover:text-white rounded-md px-3 py-2 text-sm font-medium"><i
                                        class="bi bi-clock-history block md:inline"></i> Mon Historique</a>

                            </div>
                        </div>
                    </div>
                    <div class=" md:block flex self-end">
                        <div class=" flex items-center md:ml-3">

                            <!-- Profile dropdown -->
                            <div class="relative md:ml-3">


                                <!--
                                Dropdown menu, show/hide based on menu state.

                                Entering: "transition ease-out duration-100"
                                    From: "transform opacity-0 scale-95"
                                    To: "transform opacity-100 scale-100"
                                Leaving: "transition ease-in duration-75"
                                    From: "transform opacity-100 scale-100"
                                    To: "transform opacity-0 scale-95"
                                -->
                                <form action="<?php echo e(route('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" href="<?php echo e(route('logout')); ?>"
                                        class="dropdown-item border-radius-md button items-center "
                                        style="
                                        background-color: rgb(68, 47, 20);
                                        padding:10px;
                                        border-radius: 5px; color:rgb(203, 202, 202);

                                        ">Se
                                        D&eacute;connecter</button>

                                </form>


                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>

            <!-- Mobile menu, show/hide based on menu state. -->
            
        </nav>


        <main class=" w-100">
            
            <?php echo $__env->yieldContent('contentdash'); ?>
            
        </main>
    </div>


</body>
<script>
    // Dans votre fichier JavaScript
    document.addEventListener("DOMContentLoaded", function() {
        var currentPath = window.location.pathname;
        var menuItems = document.getElementsByClassName("items_menu");

        for (var i = 0; i < menuItems.length; i++) {
            var menuItem = menuItems[i];
            var page = menuItem.getAttribute("data-page");

            if (currentPath === "/" + page) {
                menuItem.classList.add("activedash");
                break; // Si vous souhaitez arrêter la boucle après avoir trouvé l'élément actif
            }
        }
    });

    // Fonction pour changer le background d'un élément et restaurer les autres
    function changeBackground(element) {
        // Récupérer tous les éléments avec la classe "highlight"
        var highlightedElements = document.getElementsById('tri_dash');

        // Restaurer le fond des éléments précédemment mis en évidence
        for (var i = 0; i < highlightedElements.length; i++) {
            highlightedElements[i].classList.add('tri_dash');
        }

        // Appliquer le fond mis en évidence à l'élément actuel
        element.classList.remove('tri_dash');
    }

    const elementId = "already_inscrip_program"; // ID de l'élément spécifique
    const className = "already_inscrip_program"; // Nom de la classe à ajouter

    const element = document.getElementById(elementId); // Récupère l'élément par son ID

    if (element) {
        element.classList.add(className); // Ajoute la classe à l'élément
        element.style.display = "block"; // Applique le style "display: none" à l'élément

        setTimeout(() => {
            element.classList.remove(className); // Supprime la classe de l'élément
            element.style.display = "none"; // Rétablit le style d'affichage par défaut après 3 secondes
        }, 3000);
    }
</script>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/JAE/resources/views/layouts/app.blade.php ENDPATH**/ ?>
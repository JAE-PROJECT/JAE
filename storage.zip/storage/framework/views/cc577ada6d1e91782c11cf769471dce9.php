<?php $__env->startSection('content'); ?>
    <main id="page_program">
        <section id="banniere_nous_rejoindre">
            <div class="titre_page">
                <h2>Nos Programmes</h2>
 
            </div>
        </section>
        <section id="explication-program" class=" bg-color">
                    <?php if(session('already_inscrip_program')): ?>
                        <div id="already_inscrip_program" class="">
                            <div class="">
                                <p class="nom_user fs-2">Hello <?php echo e(auth()->user()->nom); ?></p>
                                <span class="warning_inscrip"><i class="bi bi-exclamation-circle-fill m-2 exclamation"></i> <?php echo e(session('already_inscrip_program')); ?></span>
                            </div>


                        </div>
                    <?php endif; ?>


            <div class="container program_explain" data-aos="fade-up">

                <div class="row gy-4" data-aos="fade-up">
                    <div class="col-lg-4">
                        <img src="<?php echo e(asset('img/newimg/programme1.jpg')); ?>" class="img-fluid" alt="oups">
                    </div>
                    <div class="col-lg-8">
                        <div class="content ps-lg-5">
                        <h3>Ce que nous faisons à la JAE</h3>
                        <p>
                            Nous organisons différents programmes et activités dans le but de former, d'encadrer, de coacher, d'éduquer, de participer à l'épanouissement personnel de chacun de nos membres.
                            La plupart de nos activités se font en ligne en attendant les programmes en présentiel et ses activités sont regroupés en deux groupes qui sont :
                        </p>
                        <ul>
                            <li><i class="bi bi-check2-circle"></i> MENTORSHIP/EDUCATION</li>
                            <li><i class="bi bi-check2-circle"></i> SOCIAL/DIVERTISSEMENT</li>
                        </ul>
                        </div>
                    </div>
                </div>

            </div>
        </section><!-- End vision_1 Section -->
        <section id="programme">
            <div class="titre_section" data-aos="fade-up">
                <h2>Programmes</h2>
            </div>
            <!-- Conteneur principal qui contient la liste des programmes -->
            <div class="container">
                <!-- Div contenant les filtres -->
                <div class="filter  mb-5">

                    <!-- Dropdown pour le statut de l'événement -->
                    <div class="dropdown ">
                        <!-- Récupération des statuts uniques des événements -->
                        <div class="d-none"><?php echo e($statuts= DB::table('event')->select('statut')->distinct()->get()); ?></div>
                        <!-- Bouton déclenchant le menu déroulant pour le choix du statut -->
                        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Statut
                        </button>
                        <!-- Menu déroulant avec les options de statut -->
                        <ul class="dropdown-menu">
                            <!-- Boucle pour afficher chaque option de statut -->
                            <?php $__currentLoopData = $statuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('programme', ['statut' => $statut->statut ] )); ?>" class="dropdown-item">
                                <?php echo e($statut->statut); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <!-- Dropdown pour le type d'événement -->
                    <div class="dropdown">
                        <!-- Récupération des types d'événements avec leurs titres -->
                        <div class="d-none">
                            <?php echo e($types = DB::table('event')->join('type', 'event.type_id', '=', 'type.id')
                            ->select('type.eventtype_titre', 'event.type_id')
                            ->get()); ?>

                        </div>
                        <!-- Bouton déclenchant le menu déroulant pour le choix du type d'événement -->
                        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            &Eacute;v&eacute;nements
                        </button>
                        <!-- Menu déroulant avec les options de type d'événement -->
                        <ul class="dropdown-menu">
                            <!-- Boucle pour afficher chaque option de type d'événement -->
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('programme',['type' => $type->type_id] )); ?>" class="dropdown-item"><?php echo e($type->eventtype_titre); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                </div>

                <div class="programmes row  position-relative">

                     
                    <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if((!isset($_GET['statut']) || $programme->statut == $_GET['statut']) && (!isset($_GET['type']) || $programme->type_id == $_GET['type'])): ?>
                        <div class="col-12 col-md-6 col-lg-4 mb-4">
                            <div class="programme mx-2" data-aos="zoom-in">

                                
                                <div class="image_program">
                                    <img src="<?php echo e(asset('img/about.jpg')); ?>" alt="">
                                    <div class="image_program-orateur">
                                        <span> ORATEUR: <?php echo e(str_replace(" - "," & ","$programme->orateur")); ?></span>
                                    </div>
                                </div>

                                <!-- Titre et description du programme -->
                                <div class="text_program px-3">
                                    <h3 class="titre_program"><?php echo e($programme->event_titre); ?></h3>
                                    <p class="description_program"><?php echo e($programme->event_description); ?></p>
                                </div>
                                
                                <!-- Bouton d'inscription -->
                                <?php if(strtolower($programme->statut) != 'ouvert'): ?>
                                    <div class="d-none bouton_inscrire pt-3">
                                        <button> Ferm&eacute;</button>
                                    </div>
                                <?php else: ?>
                                    <div class="d-block bouton_inscrire pt-3">
                                        <form action="<?php echo e(route('inscription_programme')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="event_id" value="<?php echo e($programme->id); ?>">
                                            <button type="submit">S'inscrire</button>
                                        </form>
                                    </div>
                                <?php endif; ?>

                                <!-- Informations supplémentaires sur le programme (nombre de places, date et heure) -->
                                <div class="other_infos_program mt-3">
                                    <span>
                                        <!-- <i class="bi bi-person-fill"></i> --><?php echo e($programme->nombre_place??'0'); ?> inscrits
                                    </span>
                                    <span>

                                    </span>
                                    <span>
                                        <i class="bi bi-calendar-event"></i><?php echo e($programme->event_date); ?>

                                        <i class="bi bi-hourglass-split"></i><?php echo e($programme->event_heure); ?>

                                    </span>
                                </div>

                                <!-- Statut du programme (ouvert ou fermé) -->
                                <div class="statut_program">
                                    <span>
                                        <!-- Si le programme est ouvert, affiche une coche verte, sinon affiche une croix rouge -->
                                        <?php if(strtolower($programme->statut) == 'ouvert'): ?>
                                            <i class="bi bi-record2 text-success"></i>
                                        <?php else: ?>
                                            <i class="bi bi-x text-danger"></i>
                                        <?php endif; ?>
                                        <?php echo e($programme->statut); ?>

                                    </span>
                                </div>
                            </div>
                        </div>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>
        </section>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/JAE/resources/views/nosprogramme.blade.php ENDPATH**/ ?>